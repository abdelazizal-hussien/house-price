import { useState, type FormEvent } from "react";
import locations from "../data/locations.json";
import {
  FACING_OPTIONS,
  FURNISHING_OPTIONS,
  OWNERSHIP_OPTIONS,
  TRANSACTION_OPTIONS,
  type PredictionRequest,
} from "../types/prediction";
import { formatLocationLabel } from "../utils/formatPrice";

interface FormState {
  location: string;
  carpetAreaSqft: string;
  floorNum: string;
  bathroom: string;
  balcony: string;
  furnishing: string;
  transaction: string;
  ownership: string;
  facing: string;
}

const initialState: FormState = {
  location: "",
  carpetAreaSqft: "",
  floorNum: "",
  bathroom: "",
  balcony: "",
  furnishing: "",
  transaction: "",
  ownership: "",
  facing: "",
};

type FormErrors = Partial<Record<keyof FormState, string>>;

const sortedLocations = [...(locations as string[])]
  .filter((loc) => loc !== "other")
  .sort((a, b) => formatLocationLabel(a).localeCompare(formatLocationLabel(b)));

interface PredictionFormProps {
  onSubmit: (payload: PredictionRequest) => void;
  isLoading: boolean;
  onFieldsChange?: (fields: FormState) => void;
}

export function PredictionForm({ onSubmit, isLoading, onFieldsChange }: PredictionFormProps) {
  const [fields, setFields] = useState<FormState>(initialState);
  const [errors, setErrors] = useState<FormErrors>({});

  function update<K extends keyof FormState>(key: K, value: string) {
    const next = { ...fields, [key]: value };
    setFields(next);
    onFieldsChange?.(next);
  }

  function validate(): FormErrors {
    const next: FormErrors = {};

    if (!fields.location) next.location = "Choose a location.";

    const area = Number(fields.carpetAreaSqft);
    if (!fields.carpetAreaSqft) next.carpetAreaSqft = "Enter the carpet area.";
    else if (!Number.isFinite(area) || area <= 0) next.carpetAreaSqft = "Area must be greater than 0.";
    else if (area > 20000) next.carpetAreaSqft = "That area looks too large -- double check it.";

    const floor = Number(fields.floorNum);
    if (!fields.floorNum) next.floorNum = "Enter the floor number.";
    else if (!Number.isInteger(floor)) next.floorNum = "Floor must be a whole number.";
    else if (floor < -1 || floor > 100) next.floorNum = "Use -1 for basement, 0 for ground.";

    const bathroom = Number(fields.bathroom);
    if (!fields.bathroom) next.bathroom = "Enter the number of bathrooms.";
    else if (!Number.isInteger(bathroom) || bathroom < 1) next.bathroom = "Must be at least 1.";

    const balcony = Number(fields.balcony);
    if (fields.balcony === "") next.balcony = "Enter the number of balconies (0 if none).";
    else if (!Number.isInteger(balcony) || balcony < 0) next.balcony = "Must be 0 or more.";

    if (!fields.furnishing) next.furnishing = "Choose a furnishing status.";
    if (!fields.transaction) next.transaction = "Choose a transaction type.";
    if (!fields.ownership) next.ownership = "Choose an ownership type.";
    if (!fields.facing) next.facing = "Choose which way the property faces.";

    return next;
  }

  function handleSubmit(event: FormEvent) {
    event.preventDefault();
    const validationErrors = validate();
    setErrors(validationErrors);
    if (Object.keys(validationErrors).length > 0) return;

    onSubmit({
      location: fields.location,
      carpet_area_sqft: Number(fields.carpetAreaSqft),
      floor_num: Number(fields.floorNum),
      bathroom: Number(fields.bathroom),
      balcony: Number(fields.balcony),
      furnishing: fields.furnishing,
      transaction: fields.transaction,
      ownership: fields.ownership,
      facing: fields.facing,
    });
  }

  return (
    <form onSubmit={handleSubmit} noValidate>
      <div className="field-grid">
        <div className="field field-grid--full">
          <label htmlFor="location">Location</label>
          <select
            id="location"
            value={fields.location}
            onChange={(e) => update("location", e.target.value)}
            aria-invalid={Boolean(errors.location)}
          >
            <option value="" disabled>
              Select a city or area
            </option>
            {sortedLocations.map((loc) => (
              <option key={loc} value={loc}>
                {formatLocationLabel(loc)}
              </option>
            ))}
            <option value="other">Other / not listed</option>
          </select>
          {errors.location && <span className="field__error">{errors.location}</span>}
        </div>

        <div className="field">
          <label htmlFor="carpetArea">Carpet area</label>
          <div className="field__unit">
            <input
              id="carpetArea"
              type="number"
              min={1}
              inputMode="decimal"
              placeholder="1200"
              value={fields.carpetAreaSqft}
              onChange={(e) => update("carpetAreaSqft", e.target.value)}
              aria-invalid={Boolean(errors.carpetAreaSqft)}
            />
            <span className="field__unit-label">sqft</span>
          </div>
          {errors.carpetAreaSqft && <span className="field__error">{errors.carpetAreaSqft}</span>}
        </div>

        <div className="field">
          <label htmlFor="floor">Floor</label>
          <input
            id="floor"
            type="number"
            step={1}
            placeholder="3 (0 = ground, -1 = basement)"
            value={fields.floorNum}
            onChange={(e) => update("floorNum", e.target.value)}
            aria-invalid={Boolean(errors.floorNum)}
          />
          {errors.floorNum && <span className="field__error">{errors.floorNum}</span>}
        </div>

        <div className="field">
          <label htmlFor="bathroom">Bathrooms</label>
          <input
            id="bathroom"
            type="number"
            min={1}
            step={1}
            placeholder="2"
            value={fields.bathroom}
            onChange={(e) => update("bathroom", e.target.value)}
            aria-invalid={Boolean(errors.bathroom)}
          />
          {errors.bathroom && <span className="field__error">{errors.bathroom}</span>}
        </div>

        <div className="field">
          <label htmlFor="balcony">Balconies</label>
          <input
            id="balcony"
            type="number"
            min={0}
            step={1}
            placeholder="1"
            value={fields.balcony}
            onChange={(e) => update("balcony", e.target.value)}
            aria-invalid={Boolean(errors.balcony)}
          />
          {errors.balcony && <span className="field__error">{errors.balcony}</span>}
        </div>

        <div className="field">
          <label htmlFor="furnishing">Furnishing</label>
          <select
            id="furnishing"
            value={fields.furnishing}
            onChange={(e) => update("furnishing", e.target.value)}
            aria-invalid={Boolean(errors.furnishing)}
          >
            <option value="" disabled>
              Select furnishing
            </option>
            {FURNISHING_OPTIONS.map((opt) => (
              <option key={opt} value={opt}>
                {opt}
              </option>
            ))}
          </select>
          {errors.furnishing && <span className="field__error">{errors.furnishing}</span>}
        </div>

        <div className="field">
          <label htmlFor="transaction">Transaction type</label>
          <select
            id="transaction"
            value={fields.transaction}
            onChange={(e) => update("transaction", e.target.value)}
            aria-invalid={Boolean(errors.transaction)}
          >
            <option value="" disabled>
              Select transaction type
            </option>
            {TRANSACTION_OPTIONS.map((opt) => (
              <option key={opt} value={opt}>
                {opt}
              </option>
            ))}
          </select>
          {errors.transaction && <span className="field__error">{errors.transaction}</span>}
        </div>

        <div className="field">
          <label htmlFor="ownership">Ownership</label>
          <select
            id="ownership"
            value={fields.ownership}
            onChange={(e) => update("ownership", e.target.value)}
            aria-invalid={Boolean(errors.ownership)}
          >
            <option value="" disabled>
              Select ownership type
            </option>
            {OWNERSHIP_OPTIONS.map((opt) => (
              <option key={opt} value={opt}>
                {opt}
              </option>
            ))}
          </select>
          {errors.ownership && <span className="field__error">{errors.ownership}</span>}
        </div>

        <div className="field">
          <label htmlFor="facing">Facing</label>
          <select
            id="facing"
            value={fields.facing}
            onChange={(e) => update("facing", e.target.value)}
            aria-invalid={Boolean(errors.facing)}
          >
            <option value="" disabled>
              Select facing direction
            </option>
            {FACING_OPTIONS.map((opt) => (
              <option key={opt} value={opt}>
                {opt}
              </option>
            ))}
          </select>
          {errors.facing && <span className="field__error">{errors.facing}</span>}
        </div>
      </div>

      <div className="submit-row">
        <button type="submit" className="btn-primary" disabled={isLoading}>
          {isLoading ? "Estimating..." : "Estimate value"}
        </button>
        {isLoading && <span style={{ color: "var(--color-text-muted)", fontSize: 14 }}>Talking to the model...</span>}
      </div>
    </form>
  );
}

export type { FormState };
