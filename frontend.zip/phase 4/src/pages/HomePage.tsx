import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { CropMarks } from "../components/CropMarks";
import { PredictionForm, type FormState } from "../components/PredictionForm";
import { ApiError, getPrediction } from "../api/predictionClient";
import type { PredictionRequest } from "../types/prediction";
import { formatLocationLabel } from "../utils/formatPrice";

const emptyFields: FormState = {
  location: "",
  carpetAreaSqft: "",
  floorNum: "",
  bathroom: "",
  balcony: "",
  furnishing: "",
  transaction: "",
  ownership: "",
  facing: "",
};

export function HomePage() {
  const navigate = useNavigate();
  const [fields, setFields] = useState<FormState>(emptyFields);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(payload: PredictionRequest) {
    setIsLoading(true);
    setError(null);
    try {
      const result = await getPrediction(payload);
      navigate("/result", { state: { prediction: result, request: payload } });
    } catch (err) {
      if (err instanceof ApiError) {
        setError(err.message);
      } else {
        setError("Something went wrong while estimating the price. Please try again.");
      }
    } finally {
      setIsLoading(false);
    }
  }

  const specRows: Array<{ label: string; value: string }> = [
    { label: "Location", value: fields.location ? formatLocationLabel(fields.location) : "" },
    { label: "Carpet area", value: fields.carpetAreaSqft ? `${fields.carpetAreaSqft} sqft` : "" },
    { label: "Floor", value: fields.floorNum },
    { label: "Bathrooms", value: fields.bathroom },
    { label: "Balconies", value: fields.balcony },
    { label: "Furnishing", value: fields.furnishing },
    { label: "Transaction", value: fields.transaction },
    { label: "Ownership", value: fields.ownership },
    { label: "Facing", value: fields.facing },
  ];

  return (
    <div className="page">
      <div className="sheet">
        <CropMarks />
        <header className="masthead">
          <div>
            <h1 className="masthead__title">Property Value Estimator</h1>
            <p className="masthead__subtitle">
              Enter a property's specifications and get an estimated market price, trained on
              real listings across India.
            </p>
          </div>
          <div className="masthead__index">
            Model: RandomForest
            <br />
            R&sup2; &asymp; 0.92 on held-out data
          </div>
        </header>

        <div className="workspace">
          <section className="panel" aria-labelledby="form-heading">
            <div className="panel__heading" id="form-heading">
              Property specification
            </div>
            <PredictionForm onSubmit={handleSubmit} isLoading={isLoading} onFieldsChange={setFields} />
            {error && (
              <div className="form-error" role="alert">
                {error}
              </div>
            )}
          </section>

          <aside className="panel" aria-labelledby="preview-heading">
            <div className="panel__heading" id="preview-heading">
              Spec sheet preview
            </div>
            <div className="spec-list">
              {specRows.map((row) => (
                <div className="spec-row" key={row.label}>
                  <span className="spec-row__label">{row.label}</span>
                  <span className={`spec-row__value ${row.value ? "" : "spec-row__value--empty"}`}>
                    {row.value || "not set"}
                  </span>
                </div>
              ))}
            </div>
          </aside>
        </div>
      </div>
    </div>
  );
}
