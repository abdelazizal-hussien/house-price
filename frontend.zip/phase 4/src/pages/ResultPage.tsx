import { Link, useLocation, useNavigate } from "react-router-dom";
import { CropMarks } from "../components/CropMarks";
import type { PredictionRequest, PredictionResponse } from "../types/prediction";
import { formatINR, formatLocationLabel } from "../utils/formatPrice";

interface ResultState {
  prediction: PredictionResponse;
  request: PredictionRequest;
}

export function ResultPage() {
  const location = useLocation();
  const navigate = useNavigate();
  const state = location.state as ResultState | undefined;

  if (!state) {
    return (
      <div className="page">
        <div className="sheet">
          <div className="empty-state">
            <h2>No estimate to show</h2>
            <p>Fill in a property's details first and we'll estimate its value here.</p>
            <button className="btn-primary" onClick={() => navigate("/")}>
              Go to the estimator
            </button>
          </div>
        </div>
      </div>
    );
  }

  const { prediction, request } = state;

  return (
    <div className="page">
      <div className="sheet">
        <CropMarks />
        <header className="masthead">
          <div>
            <h1 className="masthead__title">Estimated value</h1>
            <p className="masthead__subtitle">
              Based on the specification you provided, compared against similar listings.
            </p>
          </div>
        </header>

        <div className="result-panel">
          <div className="result-panel__eyebrow">Estimated market price</div>
          <div className="result-panel__price">{formatINR(prediction.predicted_price)}</div>
          <div className="dimension-line" aria-hidden="true">
            <span className="dimension-line__tick" />
            <span className="dimension-line__rule" />
            <span className="dimension-line__tick" />
          </div>
          <p className="result-panel__price-sub">
            Rs {Math.round(prediction.predicted_price).toLocaleString("en-IN")} (approximate)
          </p>

          <div className="result-specs">
            <div className="result-specs__item">
              <div className="result-specs__label">Location</div>
              <div className="result-specs__value">{formatLocationLabel(request.location)}</div>
            </div>
            <div className="result-specs__item">
              <div className="result-specs__label">Carpet area</div>
              <div className="result-specs__value">{request.carpet_area_sqft} sqft</div>
            </div>
            <div className="result-specs__item">
              <div className="result-specs__label">Floor</div>
              <div className="result-specs__value">{request.floor_num}</div>
            </div>
            <div className="result-specs__item">
              <div className="result-specs__label">Bathrooms</div>
              <div className="result-specs__value">{request.bathroom}</div>
            </div>
            <div className="result-specs__item">
              <div className="result-specs__label">Balconies</div>
              <div className="result-specs__value">{request.balcony}</div>
            </div>
            <div className="result-specs__item">
              <div className="result-specs__label">Furnishing</div>
              <div className="result-specs__value">{request.furnishing}</div>
            </div>
            <div className="result-specs__item">
              <div className="result-specs__label">Transaction</div>
              <div className="result-specs__value">{request.transaction}</div>
            </div>
            <div className="result-specs__item">
              <div className="result-specs__label">Facing</div>
              <div className="result-specs__value">{request.facing}</div>
            </div>
          </div>

          <div className="result-actions">
            <Link to="/" className="btn-secondary">
              Estimate another property
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
