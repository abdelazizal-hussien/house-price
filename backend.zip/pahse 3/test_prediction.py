import pytest
from fastapi.testclient import TestClient

from app.main import app


@pytest.fixture(scope="module")
def client():
    # TestClient must be used as a context manager to trigger the lifespan (startup/shutdown)
    # events -- otherwise app.state.model_service never gets set and every request 500s.
    with TestClient(app) as c:
        yield c


def test_health(client):
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json() == {"status": "ok"}


def test_predict_happy_path(client):
    payload = {
        "location": "mumbai",
        "carpet_area_sqft": 1200,
        "floor_num": 3,
        "bathroom": 2,
        "balcony": 1,
        "furnishing": "Semi-Furnished",
        "transaction": "Resale",
        "ownership": "Freehold",
        "facing": "East",
    }
    response = client.post("/predict", json=payload)
    assert response.status_code == 200
    body = response.json()
    assert "predicted_price" in body
    assert body["predicted_price"] > 0


def test_predict_unknown_location_falls_back_to_other(client):
    """A location outside the top-50 known list should still succeed (mapped to 'other')."""
    payload = {
        "location": "some-town-not-in-training-data",
        "carpet_area_sqft": 800,
        "floor_num": 1,
        "bathroom": 1,
        "balcony": 0,
        "furnishing": "Unfurnished",
        "transaction": "Resale",
        "ownership": "Freehold",
        "facing": "North",
    }
    response = client.post("/predict", json=payload)
    assert response.status_code == 200
    assert response.json()["predicted_price"] > 0


def test_predict_invalid_input_returns_422(client):
    payload = {
        "location": "mumbai",
        "carpet_area_sqft": -100,  # invalid: must be > 0
        "floor_num": 3,
        "bathroom": 2,
        "balcony": 1,
        "furnishing": "Semi-Furnished",
        "transaction": "Resale",
        "ownership": "Freehold",
        "facing": "East",
    }
    response = client.post("/predict", json=payload)
    assert response.status_code == 422


def test_predict_missing_field_returns_422(client):
    payload = {"location": "mumbai"}  # missing everything else
    response = client.post("/predict", json=payload)
    assert response.status_code == 422
