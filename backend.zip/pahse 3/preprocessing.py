import pandas as pd

from app.schemas.prediction import PredictionRequest

# Column order/names must match exactly what the notebook trained on (section 2.4):
# numeric_features + categorical_features
FEATURE_COLUMNS = [
    "carpet_area_sqft",
    "floor_num",
    "bathroom",
    "balcony",
    "location_grouped",
    "Furnishing",
    "Transaction",
    "Ownership",
    "facing",
]


def request_to_dataframe(req: PredictionRequest, known_locations: set[str]) -> pd.DataFrame:
    """Build a single-row DataFrame with exactly the column names used in training.

    The model's own Pipeline (ColumnTransformer -> OneHotEncoder(handle_unknown="ignore"))
    does all the actual encoding/scaling, so this function only needs to get the raw values
    into the right shape and column names -- no manual one-hot encoding here.
    """
    location_grouped = req.location if req.location in known_locations else "other"

    row = {
        "carpet_area_sqft": req.carpet_area_sqft,
        "floor_num": req.floor_num,
        "bathroom": req.bathroom,
        "balcony": req.balcony,
        "location_grouped": location_grouped,
        "Furnishing": req.furnishing,
        "Transaction": req.transaction,
        "Ownership": req.ownership,
        "facing": req.facing,
    }
    return pd.DataFrame([row], columns=FEATURE_COLUMNS)
