from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.api.routes.prediction import router as prediction_router
from app.core.config import settings
from app.services.inference import ModelService
from app.utils.logging_config import configure_logging


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Load the model ONCE here, not per-request -- joblib.load() is relatively slow and the
    # model is stateless/thread-safe to reuse across requests.
    configure_logging(settings.log_level)
    app.state.model_service = ModelService(
        model_path=settings.model_path,
        locations_path=settings.locations_path,
    )
    yield
    # (nothing to clean up on shutdown)


app = FastAPI(title="House Price Prediction API", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(prediction_router)
