from pydantic import BaseModel, Field


class PredictionRequest(BaseModel):
    """Matches the feature set the model was trained on in the notebook (section 2.4).

    `location` is free text — the backend maps it to the closest known location, or to
    "other" if it wasn't one of the top-50 locations seen during training (see
    services/preprocessing.py). Furnishing / Transaction / Ownership / facing are validated
    loosely here; the model's OneHotEncoder(handle_unknown="ignore") means an unrecognised
    value is safely encoded as "none of the known categories" rather than erroring, so we
    don't need to hard-code enums the dataset might not exactly match.
    """

    location: str = Field(..., examples=["Mumbai"], description="Free-text location/area name")
    carpet_area_sqft: float = Field(..., gt=0, le=20000, examples=[1200])
    floor_num: int = Field(..., ge=-1, le=100, examples=[3])
    bathroom: int = Field(..., ge=1, le=11, examples=[2])
    balcony: int = Field(..., ge=0, le=11, examples=[1])
    furnishing: str = Field(..., examples=["Semi-Furnished"])  # Furnished | Semi-Furnished | Unfurnished
    transaction: str = Field(..., examples=["Resale"])  # New Property | Resale | Other | Rent/Lease
    ownership: str = Field(..., examples=["Freehold"])  # Freehold | Co-operative Society | Power Of Attorney | Leasehold
    facing: str = Field(..., examples=["East"])  # East | West | North | South | North - East | ...


class PredictionResponse(BaseModel):
    predicted_price: float = Field(..., description="Predicted price in Indian rupees (Rs)")
