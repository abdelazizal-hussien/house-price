import json
import logging
from pathlib import Path

import joblib

from app.schemas.prediction import PredictionRequest
from app.services.preprocessing import request_to_dataframe

logger = logging.getLogger(__name__)


class ModelService:
    """Wraps the trained pipeline. Instantiate once at startup, reuse across requests."""

    def __init__(self, model_path: Path, locations_path: Path):
        logger.info("Loading model from %s", model_path)
        self.model = joblib.load(model_path)

        if locations_path.exists():
            with open(locations_path) as f:
                self.known_locations: set[str] = set(json.load(f))
            logger.info("Loaded %d known locations", len(self.known_locations))
        else:
            logger.warning("locations.json not found at %s -- all locations will map to 'other'", locations_path)
            self.known_locations = set()

    def predict(self, req: PredictionRequest) -> float:
        row = request_to_dataframe(req, self.known_locations)
        prediction = self.model.predict(row)[0]
        return float(prediction)
